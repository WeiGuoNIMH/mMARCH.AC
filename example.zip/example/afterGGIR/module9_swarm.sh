#!/bin/bash
#
#$ -cwd
#$ -j y
#$ -S /bin/bash
  source ~/.bash_profile


#   cd /data/guow4/project0/GGIR/postGGIR/postGGIR_compile/v2/example/afterGGIR; module load R ;   R --no-save --no-restore --args  < Example_module0.maincall.R  0
   cd /data/guow4/project0/GGIR/postGGIR/postGGIR_compile/v2/example/afterGGIR; module load R ;   R --no-save --no-restore --args  < Example_module0.maincall.R  1
   cd /data/guow4/project0/GGIR/postGGIR/postGGIR_compile/v2/example/afterGGIR; module load R ;   R --no-save --no-restore --args  < Example_module0.maincall.R  2
   cd /data/guow4/project0/GGIR/postGGIR/postGGIR_compile/v2/example/afterGGIR; module load R ;   R --no-save --no-restore --args  < Example_module0.maincall.R  3
   cd /data/guow4/project0/GGIR/postGGIR/postGGIR_compile/v2/example/afterGGIR; module load R ;   R --no-save --no-restore --args  < Example_module0.maincall.R  4



   cd /data/guow4/project0/GGIR/postGGIR/postGGIR_compile/v2/example/afterGGIR; module load R ; R -e "rmarkdown::render('module5_Example_Data_process_report.Rmd'   )" 
   cd /data/guow4/project0/GGIR/postGGIR/postGGIR_compile/v2/example/afterGGIR; module load R ; R -e "rmarkdown::render('module6_Example_NonWear.report.Rmd'   )" 
   cd /data/guow4/project0/GGIR/postGGIR/postGGIR_compile/v2/example/afterGGIR; module load R ; R -e "rmarkdown::render('module7a_Example_calculate_newfeatures.Rmd'   )" 
   cd /data/guow4/project0/GGIR/postGGIR/postGGIR_compile/v2/example/afterGGIR; module load R ; R -e "rmarkdown::render('module7b_Example_merge_GGIRfeatures.Rmd'   )" 
   cd /data/guow4/project0/GGIR/postGGIR/postGGIR_compile/v2/example/afterGGIR; module load R ; R -e "rmarkdown::render('module7c_Example_runJIVE.Rmd'   )" 
   cd /data/guow4/project0/GGIR/postGGIR/postGGIR_compile/v2/example/afterGGIR; module load R ; R -e "rmarkdown::render('module7d_Example_calculate_WD_WE_avg_features.Rmd'   )" 
